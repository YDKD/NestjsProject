import { Controller } from '@nestjs/common';

@Controller('common')
export class CommonController {}
