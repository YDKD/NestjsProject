import { ApiProperty } from "@nestjs/swagger";

/*
 * @Author: your name
 * @Date: 2021-01-05 12:35:57
 * @LastEditTime: 2021-01-05 12:36:38
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \NestjsProject\src\user\dto\find.dto.ts
 */
export class findOne  {
    @ApiProperty()
    id: number
}
