import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { iphone } from 'src/entities/phone.entity';
import { Repository } from 'typeorm';

@Injectable()
export class ShopService {
    


    
}
